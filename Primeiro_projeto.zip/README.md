# Meu Primeiro Projeto 🚀

Olá! Sou **Lucas Vinícius** e este é meu primeiro projeto no GitHub.  
Estou cursando **Análise e Desenvolvimento de Sistemas** e tenho interesse em tecnologias de informação, programação e soluções digitais.  

## O que este projeto faz?
- Exibe uma página HTML simples de apresentação.  
- Serve como ponto de partida para meu portfólio no GitHub.  

## Tecnologias usadas
- HTML5
- CSS3
